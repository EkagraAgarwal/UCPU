import time
import joblib
import pandas as pd
import json
import os
import webbrowser
import numpy as np
from datetime import datetime
from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge, Logger

logger = Logger("BluePulse")
# UI initialization (assets are now at project root /app/assets)
ui = WebUI(assets_dir_path="/app/assets")

# Absolute path helper
def get_path(filename):
    return os.path.join(os.path.dirname(__file__), filename)

# Load ML Model and Feature List
logger.info("Loading Marine Mode ML Model...")
model = None
feature_cols = []
try:
    model_path = get_path("marine_mode_pipeline.joblib")
    feature_path = get_path("feature_cols.json")
    
    model = joblib.load(model_path)
    with open(feature_path, "r") as f:
        feature_cols = json.load(f)
    logger.info(f"ML Model loaded successfully. Required features: {feature_cols}")
except Exception as e:
    logger.error(f"Failed to load ML model: {e}")

# Global state to store the latest results for the frontend
latest_data = {
    "temperature": 0.0,
    "depth": 0.0,
    "speed": 0.0,
    "roll": 0.0,
    "pitch": 0.0,
    "prediction": "Unknown",
    "probability": 0.0
}

url_opened = False

def loop():
    global latest_data, url_opened
    
    if not url_opened:
        try:
            target_url = ui.local_url # Property, not a function
            logger.info(f"Access Web Dashboard at: {target_url}")
            webbrowser.open(target_url)
            url_opened = True
        except Exception as e:
            logger.error(f"Could not auto-open browser: {e}")

    try:
        # 1. Fetch data from STM32 Bridge via RPC
        data = Bridge.call("get_telemetry")
        
        if isinstance(data, (list, tuple)) and len(data) >= 5:
            temp = float(data[0])
            depth = float(data[1])
            speed = float(data[2])
            roll = float(data[3])
            pitch = float(data[4])

            # --- Feature Engineering for ML Model ---
            now = datetime.now()
            hour = now.hour
            day_of_year = now.timetuple().tm_yday

            # Create the DataFrame explicitly with columns
            features = {
                "TEMP_clean": [temp],
                "PSAL_clean": [depth], 
                "current_speed": [speed],
                "hour_sin": [np.sin(2 * np.pi * hour / 24)],
                "hour_cos": [np.cos(2 * np.pi * hour / 24)],
                "dayofyear_sin": [np.sin(2 * np.pi * day_of_year / 365)],
                "dayofyear_cos": [np.cos(2 * np.pi * day_of_year / 365)]
            }
            input_df = pd.DataFrame(features)

            # Ensure column order matches training
            # Use only features present in feature_cols
            if model and len(feature_cols) > 0:
                # Debug log once to see what we have
                # logger.debug(f"DataFrame cols: {input_df.columns.tolist()}")
                
                input_processed = input_df[feature_cols]

                # 3. Run Inference
                prediction = model.predict(input_processed)[0]
                probabilities = model.predict_proba(input_processed)[0]
                max_prob = max(probabilities)

                # 4. Update global state
                latest_data = {
                    "temperature": temp,
                    "depth": depth,
                    "speed": speed,
                    "roll": roll,
                    "pitch": pitch,
                    "prediction": str(prediction),
                    "probability": float(max_prob)
                }
                
                # logger.debug(f"Update: {prediction} ({max_prob:.2f})")

    except Exception as e:
        # Log the full error to help pinpoint the exact line
        logger.error(f"Processing Error: {str(e)}")
        
    time.sleep(0.1)

# API Endpoint for the index.html frontend
def get_live_data():
    return latest_data

# Register the API using the correct WebUI method
ui.expose_api("GET", "/data", get_live_data)

# Start the App Lab framework
if __name__ == "__main__":
    App.run(user_loop=loop)
